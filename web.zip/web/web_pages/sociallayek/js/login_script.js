   document.addEventListener("DOMContentLoaded", function() {

        // Toggle password visibility for login form
        document.getElementById('showLoginPassword').addEventListener('change', function() {
            var passwordField = document.getElementById('loginPassword');
            passwordField.type = this.checked ? 'text' : 'password';
        });
        // Toggle password visibility for signup form
        document.getElementById('showSignupPassword').addEventListener('change', function() {
            var passwordField = document.getElementById('signupPassword');
            passwordField.type = this.checked ? 'text' : 'password';
        });
        // Form toggle functions
        window.forgottenLogin = function() {
            alert('Forgotten password functionality is not implemented.');
        };

        window.showSignupForm = function() {
            document.getElementById("login_form_div").style.display = "none";
            document.getElementById("signup_form_div").style.display = "block";
        };

        window.showLoginForm = function() {
            document.getElementById("login_form_div").style.display = "block";
            document.getElementById("signup_form_div").style.display = "none";
            document.getElementById("email_verification").style.display = "none";
        };

        window.showEmailVerificationForm = function() {
            document.getElementById("signup_form_div").style.display = "none";
            document.getElementById("email_verification").style.display = "block";
        };

        // Show messages
  function showMessage(msg) {
       const messageDiv = document.getElementById('message');
            messageDiv.textContent = msg;
            messageDiv.style.display = 'block';
        }

   // Signup form submission
document.getElementById('signupForm').addEventListener('submit', async function(event) {
      event.preventDefault();
       // Display loading message immediately on button click
            showMessage('Please wait...');
            const formData = new FormData(this);
            const password = formData.get('password');
           // Validate password length
             if (password.length !== 8) {
                  showMessage('Password is maximum 8 characters');
                  return; // Stop form submission
               }
               
            const data = {
                username: formData.get('username'),
                email: formData.get('email'),
                password: password
            };
            
            try {
                const response = await fetch('signup.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify(data)
                });
                
                const result = await response.json();
                
                if (result.mess === 'otp_sent') {
                    showEmailVerificationForm();
                } else {
                    showMessage(result.mess);
                }
            } catch (error) {
                console.error('Error:', error);
                showMessage('An error occurred. Please try again.');
            } finally {
                // Hide loading message after form submission
                document.getElementById('message').style.display = 'none';
            }
        });

  // Email verification form submission
document.getElementById('emailVeriForm').addEventListener('submit', async function(event) {
    event.preventDefault();
            const formData = new FormData(this);
            const data = {
                otp: formData.get('emailVeri')
            };
            
            try {
                const response = await fetch('signup.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify(data)
                });
                
                const result = await response.json();
                
                if (!result.mess) {
                    showMessage('Sign up successful!');
                    document.getElementById('emailVeriForm').reset();
                    showLoginForm();
                } else {
                    showMessage(result.mess);
                }
            } catch (error) {
                console.error('Error:', error);
                showMessage('An error occurred. Please try again.');
            }
        });




// Form submission handler
        document.getElementById('loginForm').addEventListener('submit', async function(event) {
            event.preventDefault(); // Prevent form from submitting the traditional way

            // Get input values
            const usernameInput = document.getElementById('loginUsername').value;
            const passwordInput = document.getElementById('loginPassword').value;

            try {
                // Send the data to the PHP file for validation
                const response = await fetch('login.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({
                        username: usernameInput,
                        password: passwordInput
                    })
                });

                const data = await response.json();
                alert(data.mess);
                if (data.mess === 'Login successful') {
                // Store username and email in local storage
                   localStorage.setItem('name', usernameInput);
                   localStorage.setItem('email', emailInput);
                 }
            } catch (error) {
                console.error('There was a problem with the fetch operation:', error);
            }
        });


});
