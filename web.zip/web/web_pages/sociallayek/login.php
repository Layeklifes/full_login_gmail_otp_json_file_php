<?php
session_start();

// File where user data is stored
$jsonFile = 'json/users.json';

// Get the JSON data from the file
$userData = file_exists($jsonFile) ? json_decode(file_get_contents($jsonFile), true) : [];

// Get the input data
$input = json_decode(file_get_contents('php://input'), true);
$username = isset($input['username']) ? $input['username'] : '';
$password = isset($input['password']) ? $input['password'] : '';

// Logging function to capture errors
function log_error($message) {
    file_put_contents('logs/errors.log', date('Y-m-d H:i:s') . " - " . $message . PHP_EOL, FILE_APPEND);
}

// Check if the username, email, and password match
if ($username && $password) {
    foreach ($userData as $user) {
        if ($user['username'] === $username &&  password_verify($password, $user['password'])) {
            echo json_encode(['mess' => 'Login successful']);
            exit;
        }
    }
    echo json_encode(['mess' => 'Invalid username, email, or password']);
} else {
    echo json_encode(['mess' => 'Invalid request']);
}
?>
