<?php
session_start();

// File where user data is stored
$jsonFile = 'json/users.json';
// Get the JSON data from the file
$userData = file_exists($jsonFile) ? json_decode(file_get_contents($jsonFile), true) : [];
// Get the input data
$input = json_decode(file_get_contents('php://input'), true);
$username = $input['username'] ?? null;
$email = $input['email'] ?? null;
$password = $input['password'] ?? null;
$otpInput = $input['otp'] ?? null;

// Logging function to capture errors
function log_error($message) {
    file_put_contents('logs/errors.log', date('Y-m-d H:i:s') . " - " . $message . PHP_EOL, FILE_APPEND);
}
// Check if the username or email already exists
if ($username && $email && $password && !$otpInput) {
    foreach ($userData as $user) {
        if ($user['username'] === $username || $user['email'] === $email) {
            echo json_encode(['mess' => 'Username or Email already exists.']);
            exit;
        }
    }

    // Generate and send OTP
    try {
        $otp = random_int(100000, 999999);
        $_SESSION['otp'] = $otp;
        $_SESSION['username'] = $username;
        $_SESSION['email'] = $email;
        $_SESSION['password'] = $password;

        include('smtp/PHPMailerAutoload.php');

        $mail = new PHPMailer(); 
        $mail->IsSMTP(); 
        $mail->SMTPAuth = true; 
        $mail->SMTPSecure = 'tls'; 
        $mail->Host = "smtp.gmail.com";
        $mail->Port = 587; 
        $mail->IsHTML(true);
        $mail->CharSet = 'UTF-8';
        //$mail->SMTPDebug = 2; 
        $mail->Username = "layeklifes@gmail.com";
        $mail->Password = "ohrcyqytvosgghkz";
        $mail->SetFrom('layeklifes@gmail.com', 'layek');
        $mail->Subject = 'Your OTP for Sociallayek';
        $mail->Body = "Your OTP is: $otp";
        $mail->AddAddress($email);
        $mail->SMTPOptions = array('ssl' => array(
            'verify_peer' => false,
            'verify_peer_name' => false,
            'allow_self_signed' => false
        ));

        if (!$mail->Send()) {
            log_error('Failed to send OTP: ' . $mail->ErrorInfo);
            echo json_encode(['mess' => 'Failed to send OTP. Please try again later.']);
        } else {
            echo json_encode(['mess' => 'otp_sent']);
        }
    } catch (Exception $e) {
        log_error('Error: ' . $e->getMessage());
        echo json_encode(['mess' => 'An error occurred. Please try again.']);
    }
    exit;
}

// Verify OTP and save user data
if ($otpInput) {
    if ($otpInput == $_SESSION['otp']) {
        // If OTP matches, add the new user to the data
        $userData[] = [
            'username' => $_SESSION['username'],
            'email' => $_SESSION['email'],
            'password' => password_hash($_SESSION['password'], PASSWORD_BCRYPT) // Encrypting the password
        ];

        // Save the updated data back to the JSON file
        file_put_contents($jsonFile, json_encode($userData, JSON_PRETTY_PRINT));

        // Clear the session data
        unset($_SESSION['otp']);
        unset($_SESSION['username']);
        unset($_SESSION['email']);
        unset($_SESSION['password']);

        // Return a success response
        echo json_encode(['mess' => false]);
    } else {
        // OTP does not match
        echo json_encode(['mess' => 'Invalid OTP.']);
    }
    exit;
}

// Default response for invalid requests
echo json_encode(['mess' => 'Invalid request.']);
?>